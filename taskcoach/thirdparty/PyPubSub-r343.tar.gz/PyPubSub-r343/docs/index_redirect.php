<?php
/* This file should be uploaded to pypubsub.sf.net to automatically 
redirect pypubsub.sf.net requests to the actual PyPubSub home page. 
Rename this file to index.html. */
header("Location: http://pubsub.sourceforge.net");
exit;
?>