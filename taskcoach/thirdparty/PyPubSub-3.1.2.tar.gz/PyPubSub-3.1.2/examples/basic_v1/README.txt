These examples demonstrate the use of the legacy (version 1) 
pubsub API. There are two examples that can be run from this folder:

**main.py**: basic console based, all in one module (so not very realistic).

**wx_main.py**: using pubsub within wxPython application, all in one module.