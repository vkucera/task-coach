For wxPython users: 

The code in this wx/lib/pubsub folder is taken verbatim from the PyPubSub
project on SourceForge.net. Pubsub originated as a wxPython lib, but it is now 
a standalone project on SourceForge. It is included as part of your wxPython 
installation for convenience to wxPython users and for backward compatiblity.

The source distribution on SF.net tends to be updated more often. If you wish to 
install pubsub standalone you can follow the instructions at 
http://pubsub.sourceforge.net/installation.html. 

The documentation for pubsub is at http://pubsub.sourceforge.net, and some examples
are in wx/lib/pubsub/examples. There are also a couple pages on the WxPython wiki
that discuss usage of pubsub in wxPython. 

Oliver Schoenborn
Dec 2011
