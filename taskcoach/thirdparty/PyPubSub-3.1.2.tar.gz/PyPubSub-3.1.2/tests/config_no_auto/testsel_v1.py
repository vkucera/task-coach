# pubsub has to load pub even if not asked by user
# because Publisher must NOT be a module but a singleton

def test_import():
    from pubsub import setupv1
    from pubsub import pub       # pubsub1 module OR
    from pubsub import Publisher # singleton from pub

    assert pub.PUBSUB_VERSION == 1
    assert Publisher() is not None
