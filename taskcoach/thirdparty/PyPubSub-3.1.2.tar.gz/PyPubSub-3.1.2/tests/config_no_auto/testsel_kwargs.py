def test_import():
    from pubsub import setupkwargs
    from pubsub import pub
    assert pub.PUBSUB_VERSION == 3
