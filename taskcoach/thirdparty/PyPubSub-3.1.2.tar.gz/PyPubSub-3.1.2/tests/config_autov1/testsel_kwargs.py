def test_import():
    from wx.lib.pubsub import setupkwargs
    from wx.lib import pubsub
    assert not hasattr(pubsub, 'pub')

    # setupkwargs must also remove 'pub' and 'Publisher' from 'pubsub'
    from wx.lib.pubsub import pub         # pubsub3 module
    assert pub.PUBSUB_VERSION == 3
