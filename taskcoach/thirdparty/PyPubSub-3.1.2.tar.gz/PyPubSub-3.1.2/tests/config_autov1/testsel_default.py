def test_import():
    # pubsub has to load pub even if not asked by user
    # because Publisher must NOT be a module but a singleton

    from wx.lib.pubsub import pub         # pubsub1 module OR
    from wx.lib.pubsub import Publisher   # singleton from pubsub1

    assert pub.PUBSUB_VERSION == 1
    assert Publisher() is not None
