class root_topic1:
    'docs for root_topic1'
    
    def msgDataSpec():
        pass
        
    class sub_topic11:
        'docs for sub_topic11'
    
class root_topic2:
    'docs for root_topic2'    

    class sub_topic21:
        'docs for sub_topic21'
