There are three sets of tests:

1. In this folder: test pubsub API v3, ie latest
2. In pubsub1: test pubsub API v1
3. In pubsub2: test pubsub API v2
4. In pubsub1in3: test pubsub API v1 exposed via latest

Tests in this folder can be run via runtests.bat. The other test
folders should be run separately (cd to folder and run nosetests).