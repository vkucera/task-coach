Welcome to wxScheduler, the new schedule library for Python made, with wxpython!
This library do the view/add/draw work for show your events, like Evolution
and other softwares.

Copyright:
    Esposti Daniele: expo --at-- expobrain -dot- net
    Michele Petrazzo: michele -dot- petrazzo --at-- unipex -dot- it
    J�r�me Laheurte: fraca7 --at-- free -dot- fr

License:
    wxWidgets License (LGPL)
    See http://www.wxwidgets.org/licence.htm for more info

Major (graphical) features:
    view type: day, week, month
    show events for read and modify
    add new events and retrieve the list
    show (only or not) work hours

Major (technical) features:
    python 2.3+
    Windows, Linux and Mac OS X
