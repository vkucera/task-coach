from distutils.core import setup
setup(name='SendKeys-ctypes',
      version='0.2',
      py_modules=['SendKeys', '_sendkeys' ],
      )
