#!/usr/bin/env python
#-*- coding: ISO-8859-1 -*-

#****h* /pysyncml.py
#  NAME
#    pysyncml -- Higher-level classes
#  COPYRIGHT
#
#  Copyright (C) 2008 J�r�me Laheurte <fraca7@free.fr>
#
# This library  is free software; you can  redistribute it and/or
# modify  it under  the terms  of the  GNU Lesser  General Public
# License as  published by  the Free Software  Foundation; either
# version  2.1 of  the License,  or  (at your  option) any  later
# version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY;  without even the implied warranty of
# MERCHANTABILITY or  FITNESS FOR A PARTICULAR  PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You  should have  received a  copy  of the  GNU Lesser  General
# Public License  along with this  library; if not, write  to the
# Free  Software Foundation,  Inc., 59  Temple Place,  Suite 330,
# Boston, MA 02111-1307 USA
#
#  CREATION DATE
#    14 Jun 2008
#***

"""

This module is a higher-level, more Pythonish API for classes wrapped
in L{_pysyncml}. As a convenience, all objects defined in L{_pysyncml}
are available in this namespace.

@author: J�r�me Laheurte
@contact: fraca7@free.fr
@copyright: (c) 2008

"""

__rcsid__ = '$Id: pysyncml.py 71 2011-07-29 12:05:32Z fraca7 $'

version = (0, 3)

if __name__ == '__main__':
    import sys
    sys.stdout.write('.'.join(map(str, version)))
    sys.exit(0)

from _pysyncml import *

from xml.etree import ElementTree as ET

#==============================================================================
#{ Sync sources

class PySyncSource(SyncSource):
    """This class behaves like a L{SyncSource}, but provides default
    implementations for the iterators."""

    def __init__(self, items, *args, **kwargs):
        """Constructor.
        @param items: This must be an iterator over all local items.
        These items must provide the following methods:

          - isNew()
          - isModified()
          - isDeleted()

        Iteration over items is implemented by way of generators, to
        avoid excessive memory usage when a great number of items are
        fetched from disk, for instance."""

        super(PySyncSource, self).__init__(*args, **kwargs)

        self.__items = items

    def mapToSyncItem(self, obj):
        """Pure virtual method.
        @return: A L{SyncItem} instance representing the local
        item 'obj'.
        @param obj: A local item."""

        raise NotImplementedError

    def __nextItem(self, ls):
        try:
            obj = ls.next()
        except StopIteration:
            return None

        item = self.mapToSyncItem(obj)

        if obj.isNew():
            item.state = STATE_NEW
        elif obj.isModified():
            item.state = STATE_UPDATED
        elif obj.isDeleted():
            item.state = STATE_DELETED
        else:
            item.state = STATE_NONE

        return item

    def getFirstItem(self):
        "@return: The first item"

        def allItems(items):
            for item in items:
                yield item
        self.__allItems = allItems(self.__items)

        return self.__nextItem(self.__allItems)

    def getNextItem(self):
        "@return: The next item"

        return self.__nextItem(self.__allItems)

    def getFirstNewItem(self):
        "@return: The first new item"

        def newItems(items):
            for item in items:
                if item.isNew():
                    yield item
        self.__newItems = newItems(self.__items)

        return self.__nextItem(self.__newItems)

    def getNextNewItem(self):
        "@return: The next new item"

        return self.__nextItem(self.__newItems)

    def getFirstUpdatedItem(self):
        "@return: The first updated item"

        def updatedItems(items):
            for item in items:
                if item.isModified():
                    yield item
        self.__updatedItems = updatedItems(self.__items)

        return self.__nextItem(self.__updatedItems)

    def getNextUpdatedItem(self):
        "@return: The next updated item"

        return self.__nextItem(self.__updatedItems)

    def getFirstDeletedItem(self):
        "@return: The first deleted item"

        def deletedItems(items):
            for item in items:
                if item.isModified():
                    yield item
        self.__deletedItems = deletedItems(self.__items)

        return self.__nextItem(self.__deletedItems)

    def getNextDeletedItem(self):
        "@return: The next deleted item"

        return self.__nextItem(self.__deletedItems)

#}

#==============================================================================
#{ XML persistence

class XMLManagementNode(ManagementNode):
    """Management node used by L{XMLDMTree}."""

    def __init__(self, element, *args, **kwargs):
        super(XMLManagementNode, self).__init__(*args, **kwargs)

        self.element = element

    def getChildrenMaxCount(self):
        return len(self.element.findall('property'))

    def getChildrenNames(self):
        return [elt.attrib['name'] for elt in self.element.findall('property')]

    def readPropertyValue(self, name):
        for elt in self.element.findall('property'):
            if elt.attrib['name'] == name:
                return elt.text
        return ''

    def setPropertyValue(self, name, value):
        for elt in self.element.findall('property'):
            if elt.attrib['name'] == name:
                elt.text = value
                break
        else:
            elt = ET.SubElement(self.element, 'property')
            elt.attrib['name'] = name
            elt.text = value

    def clone(self):
        return self

class XMLDMTree(DMTree):
    """DMTree mapping to an XML file."""

    def __init__(self, rootElement, *args, **kwargs):
        super(XMLDMTree, self).__init__(*args, **kwargs)

        self.rootElement = rootElement

    def __getNode(self, node):
        elt = self.rootElement

        for name in node.split('/'):
            if elt.find(name):
                elt = elt.find(name)
            else:
                elt = ET.SubElement(elt, name)

        return XMLManagementNode(elt, node)

    def isLeaf(self, node):
        return self.__getNode(node).getMaxChildrenCount() == 0

    def readManagementNode(self, node):
        return self.__getNode(node)

class XMLDMTClientConfig(DMTClientConfig):
    """A DMTClientConfig that reads and saves data to an XML file."""

    def __init__(self, xmlFilename, *args, **kwargs):
        """@param xmlFilename: Path to the XML file"""

        super(XMLDMTClientConfig, self).__init__(*args, **kwargs)

        self.xmlFilename = xmlFilename

    def createDMTree(self, rootContext):
        return XMLDMTree(self.rootElement, rootContext)

    def open(self):
        if os.path.exists(self.xmlFilename):
            self.rootElement = ET.parse(self.xmlFilename).getroot()
        else:
            self.rootElement = ET.Element('funambol')

        return super(XMLDMTClientConfig, self).open()

    def close(self):
        super(XMLDMTClientConfig, self).close()

        tree = ET.ElementTree(self.rootElement)
        tree.write(self.xmlFilename)

#}
